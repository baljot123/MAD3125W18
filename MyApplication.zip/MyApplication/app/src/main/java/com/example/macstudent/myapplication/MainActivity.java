package com.example.macstudent.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ListView receiptList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        receiptList =  (ListView) findViewById(R.id.list_receipt);
        receiptList.setAdapter(new ReportAdapter(getApplicationContext()));


    }
}
